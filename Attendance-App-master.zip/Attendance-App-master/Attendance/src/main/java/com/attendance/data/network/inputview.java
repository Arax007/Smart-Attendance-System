package com.attendance.data.network;

import android.support.design.widget.TextInputEditText;

/**
 * Created by coolalien on 17,March,2017
 */

public interface inputview {

    TextInputEditText gettext();

}
